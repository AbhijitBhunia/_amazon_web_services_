import boto3

region = "ap-south-1"
def lambda_handler(event, context):
    instance_id = event['detail']['instance-id']
    state = event['detail']["state"]
    region = event["region"]
    resources_ARN = event["resources"][0]

    ec2 = boto3.client('ec2', region)
    myinstance = ec2.describe_instances(InstanceIds=[instance_id])

    AMI_ID = myinstance['Reservations'][0]['Instances'][0]['ImageId']
    Instance_type = myinstance['Reservations'][0]['Instances'][0]['InstanceType']

    MY_SNS_TOPIC_ARN = "arn:aws:sns:ap-south-1:418887156176:state_change_sns_notify"
    sns_client = boto3.client('sns', region)
    msg = 'Instance ID:   ' + instance_id + '\n' + 'State:   ' + state + '\n' + 'Region:   ' + region + '\n' + 'Instance AMI ID:   ' + AMI_ID + '\n' + 'Instance type:   ' + Instance_type + '\n' + 'Instance ARN:   ' + resources_ARN

    if (state == "running"):
        sub = 'EC2 Instance (' + instance_id + ') State changed to Running'
        sns_client.publish(
            TopicArn = MY_SNS_TOPIC_ARN,
            Subject = sub,
            Message = msg
        )
    elif (state == "stopped"):
        sub = 'EC2 Instance (' + instance_id + ') State changed to Stopped'
        sns_client.publish(
            TopicArn = MY_SNS_TOPIC_ARN,
            Subject = sub,
            Message = msg
        )
    elif (state == "terminated"):
        sub = 'EC2 Instance (' + instance_id + ') State changed to Terminated'
        sns_client.publish(
            TopicArn = MY_SNS_TOPIC_ARN,
            Subject = sub,
            Message = msg
        )

